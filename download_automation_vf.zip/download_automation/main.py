from data_transformation import transformation
from download_files import download
from unzip_file import unzip
from pathlib import Path

if __name__ == '__main__':
    path = str(Path.home() / "Downloads")
    download()
    unzip(path)
    transformation()
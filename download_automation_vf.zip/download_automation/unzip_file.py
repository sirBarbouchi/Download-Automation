import shutil         
import glob
import zipfile
import os
def unzip(path):
    """
    this function searches all downloaded files (TAXRATES_ZIP5.zip), select the last downloaded, copy it to the directory of the program, and unzip it
    """
    list_of_files = glob.glob(path+'/*')
    latest_file = max(list_of_files, key=os.path.getmtime)
    shutil.copyfile(latest_file, r".\target.zip")
   
    with zipfile.ZipFile(r".\target.zip", 'r') as zip_ref:
        zip_ref.extractall(r"./")
